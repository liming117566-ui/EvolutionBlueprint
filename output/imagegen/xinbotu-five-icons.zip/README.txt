新博途图标探索 · 5 个不同方向
模型：gpt-image-2.6；使用用户指定图片接口生成。
所有 PNG 原图均为 1024×1024，不预裁圆角。现有应用图标未替换。

1 知识跃迁 / 钴蓝 / 01-cobalt-knowledge-leap.png
2 灵感纸翼 / 珊瑚红 / 02-coral-paper-wings.png
3 思维星核 / 紫罗兰 / 03-violet-star-core.png
4 拾级而上 / 琥珀黄 / 04-amber-upward-route.png
5 无限探索 / 湖蓝 / 05-aqua-infinite-discovery.png

完整提示词见 prompts.json。
